package com.healthmate.app

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import android.content.*
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val purple = Color.rgb(124,58,237)
    private val bg = Color.rgb(251,250,255)
    private val prefs by lazy { getSharedPreferences("healthmate", MODE_PRIVATE) }
    private lateinit var content: LinearLayout

    override fun onCreate(b: Bundle?) { super.onCreate(b); showHome() }

    private fun base(): LinearLayout {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(bg)
        val top=LinearLayout(this); top.setPadding(24,22,20,12); top.gravity=Gravity.CENTER_VERTICAL
        val brand=TextView(this); brand.text="HealthMate"; brand.textSize=25f; brand.setTextColor(purple); brand.setTypeface(null,1)
        top.addView(brand, LinearLayout.LayoutParams(0,65,1f))
        val avatar=TextView(this); avatar.text="HM"; avatar.gravity=17; avatar.setTextColor(purple); avatar.setBackgroundColor(Color.rgb(239,231,255))
        top.addView(avatar, LinearLayout.LayoutParams(48,48))
        root.addView(top)
        content=LinearLayout(this); content.orientation=LinearLayout.VERTICAL; content.setPadding(18,8,18,95)
        val scroll=ScrollView(this); scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this); nav.setPadding(5,8,5,8); nav.setBackgroundColor(Color.WHITE)
        listOf("⌂\nHome","◉\nScan","☰\nMeals","⚙\nProfile").forEachIndexed { i,s ->
            val v=Button(this); v.text=s; v.textSize=12f; v.setTextColor(if(i==0) purple else Color.DKGRAY); v.setOnClickListener{when(i){0->showHome();1->showScan();2->showMeals();3->showProfile()}}
            nav.addView(v,LinearLayout.LayoutParams(0,65,1f))
        }
        root.addView(nav); return root
    }
    private fun title(a:String,b:String){ val t=TextView(this);t.text="$a\n$b";t.setPadding(4,12,4,18);t.textSize=23f;t.setTextColor(Color.rgb(32,26,45));t.setTypeface(null,1);content.addView(t) }
    private fun card(text:String):TextView { val v=TextView(this);v.text=text;v.textSize=16f;v.setTextColor(Color.rgb(40,32,50));v.setPadding(22,22,22,22);v.setBackgroundColor(Color.WHITE);content.addView(v,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)});return v }
    private fun button(text:String, action:()->Unit){ val b=Button(this);b.text=text;b.setTextColor(Color.WHITE);b.setBackgroundColor(purple);b.setOnClickListener{action()};content.addView(b,LinearLayout.LayoutParams(-1,58).apply{setMargins(0,8,0,8)}) }

    private fun showHome(){setContentView(base());title("Good day 👋","Your health, simplified.");button("📸  Scan Food"){showScan()};val t=totals();card("TODAY\n\nCalories   ${t.first} kcal\nProtein     ${t.second} g\nCarbs       ${t.third} g\nFat         ${t.fourth} g\n\nTarget: 2000 kcal");card(if(getMeals().length()==0)"No meals yet. Scan your first meal.\n\nAI food recognition is ready to connect." else "Recent meals\n\n"+mealText());}
    private fun showScan(){setContentView(base());title("Nutrition scanner","Analyze a meal");button("📷  Take / Choose Food Photo"){pickPhoto()};button("▦  Scan Barcode"){toast("Barcode workflow ready. Connect an open product database for live lookup.")};card("OR LOG MANUALLY");val name=EditText(this);name.hint="Food name";content.addView(name);val cal=EditText(this);cal.hint="Calories";cal.inputType=2;content.addView(cal);val pro=EditText(this);pro.hint="Protein (g)";pro.inputType=2;content.addView(pro);val carb=EditText(this);carb.hint="Carbs (g)";carb.inputType=2;content.addView(carb);val fat=EditText(this);fat.hint="Fat (g)";fat.inputType=2;content.addView(fat);button("Add meal"){addMeal(name.text.toString().ifBlank{"Meal"},cal.text.toString().toIntOrNull()?:0,pro.text.toString().toIntOrNull()?:0,carb.text.toString().toIntOrNull()?:0,fat.text.toString().toIntOrNull()?:0,"Manual");showHome()}}
    private fun pickPhoto(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},10)}
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK){showScan();val samples=arrayOf(arrayOf("Dal Rice",480,16,72,13),arrayOf("Paneer Roti",520,22,55,22),arrayOf("Idli Sambar",330,11,55,7),arrayOf("Veg Thali",620,20,82,21));val x=samples.random();button("Add estimated ${x[0]} — ${x[1]} kcal"){addMeal(x[0].toString(),x[1] as Int,x[2] as Int,x[3] as Int,x[4] as Int,"Scanned");showHome()};card("AI ESTIMATE\n${x[0]}\nCalories: ${x[1]} kcal  •  Protein: ${x[2]}g\nCarbs: ${x[3]}g  •  Fat: ${x[4]}g\n\nPrototype mode: this result is a sample estimate, not real AI recognition.")}}
    private fun showMeals(){setContentView(base());title("Meal history","Everything you've logged");card(if(getMeals().length()==0)"No meals logged." else mealText());button("Clear history"){prefs.edit().remove("meals").apply();showMeals()}}
    private fun showProfile(){setContentView(base());title("Settings","HealthMate");card("Theme\nPurple");card("Subscription\nFREE");card("Storage\nSaved locally on this device");card("AI + barcode\nProduction connections can be added without changing the app UI.")}
    private fun addMeal(n:String,c:Int,p:Int,ca:Int,f:Int,type:String){val a=getMeals();a.put(JSONObject().apply{put("name",n);put("cal",c);put("pro",p);put("carb",ca);put("fat",f);put("type",type)});prefs.edit().putString("meals",a.toString()).apply();toast("Meal added")}
    private fun getMeals():JSONArray=try{JSONArray(prefs.getString("meals","[]"))}catch(e:Exception){JSONArray()}
    private fun totals():Array<Int>{var c=0;prefs.getString("meals","[]")?.let{try{val a=JSONArray(it);var p=0;var ca=0;var f=0;for(i in 0 until a.length()){val x=a.getJSONObject(i);c+=x.optInt("cal");p+=x.optInt("pro");ca+=x.optInt("carb");f+=x.optInt("fat")};return arrayOf(c,p,ca,f)}catch(_:Exception){}};return arrayOf(0,0,0,0)}
    private fun mealText():String{val a=getMeals();val s=StringBuilder();for(i in a.length()-1 downTo 0){val x=a.getJSONObject(i);s.append("🥗 ${x.optString("name")} — ${x.optInt("cal")} kcal\n${x.optInt("pro")}g protein • ${x.optInt("carb")}g carbs • ${x.optInt("fat")}g fat\n\n")};return s.toString()}
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
}
